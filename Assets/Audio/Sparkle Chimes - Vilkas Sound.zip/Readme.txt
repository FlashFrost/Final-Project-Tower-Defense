Thanks For Downloading!

-----------------------------------------------------------------------------
Usage: => All Sounds are Royalty-Free and No-Copyright. However you must give credit to "Vilkas Sound" and Link to the Youtube channel/video if possible.

License: => All Sounds are under Attribution 4.0 International (CC BY 4.0) License.

More info here:
https://creativecommons.org/licenses/by/4.0/
-----------------------------------------------------------------------------

Good Luck with your project and Have Fun!

-Vilkas Sound


Socials:

YOUTUBE: https://www.youtube.com/channel/UC3fQ3k55Hyi2bcRJo_gdAnA/
SOUNDCLOUD: https://soundcloud.com/user-441810979
TWITTER: https://twitter.com/soundvilkas